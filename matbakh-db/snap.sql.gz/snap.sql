-- Private Matbakh SQL snapshot. Includes credential hashes and session records.
-- Review before restoring: DROP TABLE statements replace target tables.
SET NAMES utf8mb4;
SET time_zone='+00:00';
SET sql_mode='';
SET foreign_key_checks=0;

-- Table __drizzle_migrations
DROP TABLE IF EXISTS `__drizzle_migrations`;
CREATE TABLE `__drizzle_migrations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `hash` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` bigint DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=830381;
INSERT INTO `__drizzle_migrations` (`id`,`hash`,`created_at`) VALUES ('1','96168d50097c6d417b7449651a2e617a98e7ffd93dbc832e9cf1d2a0c237a0ec','1788785580464');
INSERT INTO `__drizzle_migrations` (`id`,`hash`,`created_at`) VALUES ('2','0f18b1773b45748dd27554c98357cead334175a175a49b234c343e33d5c2af64','1792965494325');
INSERT INTO `__drizzle_migrations` (`id`,`hash`,`created_at`) VALUES ('3','770fff471ba6e64722a8fd012ad7d4fa57bf665f2cbbad37218a89038e77c29a','1792965729767');
INSERT INTO `__drizzle_migrations` (`id`,`hash`,`created_at`) VALUES ('4','49e4f7ed8ed046344171b8cd54b3ebae603e9e2636341dcf2d2dbbb749335ace','1792973448117');
INSERT INTO `__drizzle_migrations` (`id`,`hash`,`created_at`) VALUES ('5','31abc38fa238032d6ebc749ed780783b44281d89999bfc70b3329dd707335c46','1793084565861');
INSERT INTO `__drizzle_migrations` (`id`,`hash`,`created_at`) VALUES ('6','d4c1ce7f2325fc9a3f9ec11a2c081f7216ba7da56c246df6e2436c22f0da64f7','1793176820283');
INSERT INTO `__drizzle_migrations` (`id`,`hash`,`created_at`) VALUES ('7','27b5b34665fffb137c8995b2f66f2eab2eb493e94ae0c15eddf60e19a76034f0','1793305765272');
INSERT INTO `__drizzle_migrations` (`id`,`hash`,`created_at`) VALUES ('8','731009cd20b8ebc03ead9a96c330189c7e3e6e3af2de9a4e4f502b166ba4fe47','1793379600000');

-- Table branches
DROP TABLE IF EXISTS `branches`;
CREATE TABLE `branches` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordersEnabled` tinyint(1) NOT NULL DEFAULT '1',
  `isLegacy` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `branches_name_city_uq` (`name`,`city`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=30001;
INSERT INTO `branches` (`id`,`name`,`city`,`ordersEnabled`,`isLegacy`,`createdAt`) VALUES (1,'فرع فيصل','نابلس',1,1,'2026-10-30 19:55:22');
INSERT INTO `branches` (`id`,`name`,`city`,`ordersEnabled`,`isLegacy`,`createdAt`) VALUES (2,'فرع سفيان','نابلس',1,1,'2026-10-30 19:55:22');
INSERT INTO `branches` (`id`,`name`,`city`,`ordersEnabled`,`isLegacy`,`createdAt`) VALUES (3,'فرع رفيديا','نابلس',0,1,'2026-10-30 19:55:22');
INSERT INTO `branches` (`id`,`name`,`city`,`ordersEnabled`,`isLegacy`,`createdAt`) VALUES (4,'فرع بلازا مول','رام الله',1,1,'2026-10-30 19:55:22');
INSERT INTO `branches` (`id`,`name`,`city`,`ordersEnabled`,`isLegacy`,`createdAt`) VALUES (5,'فرع الطيرة','رام الله',1,1,'2026-10-30 19:55:22');

-- Table broadcast_chunks
DROP TABLE IF EXISTS `broadcast_chunks`;
CREATE TABLE `broadcast_chunks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `broadcast_id` int NOT NULL,
  `sequence` int NOT NULL,
  `data` longblob NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `broadcast_chunk_sequence_uq` (`broadcast_id`,`sequence`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table broadcast_listens
DROP TABLE IF EXISTS `broadcast_listens`;
CREATE TABLE `broadcast_listens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `broadcast_id` int NOT NULL,
  `user_id` int NOT NULL,
  `listened_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `broadcast_listen_user_uq` (`broadcast_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table broadcasts
DROP TABLE IF EXISTS `broadcasts`;
CREATE TABLE `broadcasts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `branch_id` int NOT NULL,
  `sender_id` int NOT NULL,
  `sender_name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_section` enum('station','kitchen') COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_id` int DEFAULT NULL,
  `title` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('live','ended','interrupted') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'live',
  `sample_rate` int NOT NULL DEFAULT '16000',
  `total_bytes` int NOT NULL DEFAULT '0',
  `total_chunks` int NOT NULL DEFAULT '0',
  `started_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_chunk_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ended_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  KEY `broadcast_branch_state_idx` (`branch_id`,`status`),
  KEY `broadcast_order_idx` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table data_migration_journal
DROP TABLE IF EXISTS `data_migration_journal`;
CREATE TABLE `data_migration_journal` (
  `marker` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `applied_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `details` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`marker`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table developer_errors
DROP TABLE IF EXISTS `developer_errors`;
CREATE TABLE `developer_errors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `branch_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `severity` enum('info','warning','error','critical') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'error',
  `source` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `route` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('new','investigating','resolved','ignored') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'new',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `resolved_at` timestamp NULL DEFAULT NULL,
  `resolved_by_id` int DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  KEY `developer_errors_branch_created_idx` (`branch_id`,`created_at`),
  KEY `developer_errors_status_idx` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table feature_flags
DROP TABLE IF EXISTS `feature_flags`;
CREATE TABLE `feature_flags` (
  `id` int NOT NULL AUTO_INCREMENT,
  `feature_key` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target` enum('developer','branch','all') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'developer',
  `branch_id` int DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `created_by_id` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `feature_flags_feature_target_uq` (`feature_key`,`target`,`branch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table integration_api_keys
DROP TABLE IF EXISTS `integration_api_keys`;
CREATE TABLE `integration_api_keys` (
  `id` int NOT NULL AUTO_INCREMENT,
  `branch_id` int NOT NULL,
  `label` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token_hash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token_prefix` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by_id` int DEFAULT NULL,
  `created_by_name` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `revoked_at` timestamp NULL DEFAULT NULL,
  `revoked_by_id` int DEFAULT NULL,
  `revoked_by_name` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `integration_api_keys_token_hash_uq` (`token_hash`),
  KEY `integration_api_keys_branch_created_idx` (`branch_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table integration_attempts
DROP TABLE IF EXISTS `integration_attempts`;
CREATE TABLE `integration_attempts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `outbox_id` int NOT NULL,
  `branch_id` int NOT NULL,
  `status` enum('sent','failed','skipped') COLLATE utf8mb4_unicode_ci NOT NULL,
  `response_status` int DEFAULT NULL,
  `error` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attempted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `duration_ms` int DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  KEY `integration_attempts_outbox_attempted_idx` (`outbox_id`,`attempted_at`),
  KEY `integration_attempts_branch_attempted_idx` (`branch_id`,`attempted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table integration_key_audit
DROP TABLE IF EXISTS `integration_key_audit`;
CREATE TABLE `integration_key_audit` (
  `id` int NOT NULL AUTO_INCREMENT,
  `branch_id` int NOT NULL,
  `key_id` int DEFAULT NULL,
  `action` enum('created','revoked') COLLATE utf8mb4_unicode_ci NOT NULL,
  `actor_id` int DEFAULT NULL,
  `actor_name` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `detail` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  KEY `integration_key_audit_branch_created_idx` (`branch_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table integration_outbox
DROP TABLE IF EXISTS `integration_outbox`;
CREATE TABLE `integration_outbox` (
  `id` int NOT NULL AUTO_INCREMENT,
  `branch_id` int NOT NULL,
  `order_id` int DEFAULT NULL,
  `event_type` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pending','delivered','failed','skipped') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `attempts` int NOT NULL DEFAULT '0',
  `next_attempt_at` timestamp NULL DEFAULT NULL,
  `last_error` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivered_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  KEY `integration_outbox_pending_scan_idx` (`status`,`next_attempt_at`,`id`),
  KEY `integration_outbox_branch_created_idx` (`branch_id`,`created_at`),
  KEY `integration_outbox_order_event_idx` (`order_id`,`event_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table integration_webhook_configs
DROP TABLE IF EXISTS `integration_webhook_configs`;
CREATE TABLE `integration_webhook_configs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `branch_id` int NOT NULL,
  `webhook_url` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `provider_configured` tinyint(1) NOT NULL DEFAULT '0',
  `updated_by_id` int DEFAULT NULL,
  `updated_by_name` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `integration_webhook_configs_branch_uq` (`branch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table kitchenOrderEvents
DROP TABLE IF EXISTS `kitchenOrderEvents`;
CREATE TABLE `kitchenOrderEvents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `orderId` int NOT NULL,
  `status` enum('new','preparing','ready','received') COLLATE utf8mb4_unicode_ci NOT NULL,
  `actor` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'موظف الوردية',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `detail` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kind` enum('created','accepted','ready','received','extended') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'created',
  `actorId` int DEFAULT NULL,
  `previousDueAt` timestamp NULL DEFAULT NULL,
  `newDueAt` timestamp NULL DEFAULT NULL,
  `addedMinutes` int DEFAULT NULL,
  `reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table kitchenOrderItems
DROP TABLE IF EXISTS `kitchenOrderItems`;
CREATE TABLE `kitchenOrderItems` (
  `id` int NOT NULL AUTO_INCREMENT,
  `orderId` int NOT NULL,
  `productId` int NOT NULL,
  `productName` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int NOT NULL,
  `prepMinutes` int NOT NULL,
  `graceMinutes` int NOT NULL DEFAULT '5',
  `hasTimer` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table kitchenOrders
DROP TABLE IF EXISTS `kitchenOrders`;
CREATE TABLE `kitchenOrders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `orderCode` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('new','preparing','ready','received') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'new',
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `acceptedAt` timestamp NULL DEFAULT NULL,
  `readyAt` timestamp NULL DEFAULT NULL,
  `voiceData` longblob DEFAULT NULL,
  `voiceType` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `branchId` int DEFAULT NULL,
  `orderSource` enum('internal','kitchen_manager','external') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'internal',
  `createdById` int DEFAULT NULL,
  `createdByName` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acceptedById` int DEFAULT NULL,
  `receivedAt` timestamp NULL DEFAULT NULL,
  `receivedById` int DEFAULT NULL,
  `receivedByName` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `extensionMinutes` int NOT NULL DEFAULT '0',
  `originalDueAt` timestamp NULL DEFAULT NULL,
  `effectiveDueAt` timestamp NULL DEFAULT NULL,
  `everOverdue` tinyint(1) NOT NULL DEFAULT '0',
  `externalOrderId` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `externalItemId` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `syncStatus` enum('pending','synced','error','not_required') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'not_required',
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `kitchenOrders_orderCode_unique` (`orderCode`),
  UNIQUE KEY `orders_external_item_uq` (`branchId`,`externalOrderId`,`externalItemId`),
  KEY `orders_branch_status_idx` (`branchId`,`status`),
  KEY `orders_branch_created_idx` (`branchId`,`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table notification_reads
DROP TABLE IF EXISTS `notification_reads`;
CREATE TABLE `notification_reads` (
  `id` int NOT NULL AUTO_INCREMENT,
  `notification_id` int NOT NULL,
  `user_id` int NOT NULL,
  `read_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `notification_read_user_uq` (`notification_id`,`user_id`),
  KEY `notification_read_user_idx` (`user_id`,`read_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table notifications
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `branch_id` int NOT NULL,
  `order_id` int DEFAULT NULL,
  `type` varchar(48) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_section` enum('station','kitchen','all') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'all',
  `target_role` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dedupe_key` varchar(220) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `notification_dedupe_uq` (`dedupe_key`),
  KEY `notification_branch_created_idx` (`branch_id`,`created_at`),
  KEY `notification_order_created_idx` (`order_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table products
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'دجاج',
  `prepMinutes` int NOT NULL DEFAULT '10',
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `sortOrder` int NOT NULL DEFAULT '0',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `branchId` int DEFAULT NULL,
  `graceMinutes` int NOT NULL DEFAULT '5',
  `hasTimer` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `products_branch_name_uq` (`branchId`,`name`),
  KEY `products_branch_active_idx` (`branchId`,`isActive`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=30001;
INSERT INTO `products` (`id`,`name`,`category`,`prepMinutes`,`isActive`,`sortOrder`,`createdAt`,`updatedAt`,`branchId`,`graceMinutes`,`hasTimer`) VALUES (1,'كرسبي','دجاج',8,1,10,'2026-10-30 19:48:06','2026-10-30 19:48:06',NULL,5,1);
INSERT INTO `products` (`id`,`name`,`category`,`prepMinutes`,`isActive`,`sortOrder`,`createdAt`,`updatedAt`,`branchId`,`graceMinutes`,`hasTimer`) VALUES (2,'بروست','دجاج',12,1,20,'2026-10-30 19:48:06','2026-10-30 19:48:06',NULL,5,1);

-- Table push_subscriptions
DROP TABLE IF EXISTS `push_subscriptions`;
CREATE TABLE `push_subscriptions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `endpoint` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL,
  `endpoint_hash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p256dh` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `auth` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `push_subscription_endpoint_hash_uq` (`endpoint_hash`),
  KEY `push_subscription_user_updated_idx` (`user_id`,`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table release_manifests
DROP TABLE IF EXISTS `release_manifests`;
CREATE TABLE `release_manifests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `artifact_name` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `artifact_data` longblob DEFAULT NULL,
  `artifact_size` int DEFAULT NULL,
  `status` enum('uploaded','testing','approved','deployed','rolled_back') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'uploaded',
  `target` enum('developer','branch','all') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'developer',
  `target_branch_id` int DEFAULT NULL,
  `created_by_id` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  KEY `release_manifests_version_idx` (`version`),
  KEY `release_manifests_status_idx` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table settings
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `setting_key` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `setting_value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`setting_key`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table staff_feedback
DROP TABLE IF EXISTS `staff_feedback`;
CREATE TABLE `staff_feedback` (
  `id` int NOT NULL AUTO_INCREMENT,
  `branch_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  `order_id` int DEFAULT NULL,
  `title` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `priority` enum('low','normal','high','urgent') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal',
  `attachment_data` longblob DEFAULT NULL,
  `attachment_name` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_type` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('new','investigating','resolved','closed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'new',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `resolved_by_id` int DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  KEY `staff_feedback_branch_created_idx` (`branch_id`,`created_at`),
  KEY `staff_feedback_status_idx` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table staff_sessions
DROP TABLE IF EXISTS `staff_sessions`;
CREATE TABLE `staff_sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token_hash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int NOT NULL,
  `expires_at` timestamp NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `staff_sessions_token_uq` (`token_hash`),
  KEY `staff_sessions_user_expiry_idx` (`user_id`,`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=120001;

-- Table staff_users
DROP TABLE IF EXISTS `staff_users`;
CREATE TABLE `staff_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `can_station` tinyint(1) NOT NULL DEFAULT '0',
  `can_kitchen` tinyint(1) NOT NULL DEFAULT '0',
  `can_manager` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `must_change_password` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `role` enum('developer','system_admin','branch_manager','kitchen_manager','shift_manager','station','kitchen') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'station',
  `branch_id` int DEFAULT NULL,
  `can_manage_users` tinyint(1) NOT NULL DEFAULT '0',
  `can_broadcast` tinyint(1) NOT NULL DEFAULT '0',
  `can_extend` tinyint(1) NOT NULL DEFAULT '0',
  `usual_shift` enum('morning','evening','flexible') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `staff_users_username_uq` (`username`),
  KEY `staff_users_branch_role_idx` (`branch_id`,`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=90001;
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (1,'manager','مدير النظام','scrypt$b3f38ef423675a61da3f2d02371b19a0$aa6f9d61c369af0326a6d76a3301dd777ef43041537abda2aa141d0386ac5370ec2a410c45d5961b14f924dacd432cdbfa13ad11ff25377c35f3fbaa9cb88a03',1,1,1,1,0,'2026-10-30 19:51:58','2026-10-30 19:53:18','system_admin',NULL,1,1,1,NULL);
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (30001,'developer','مطوّر النظام','scrypt$acd02aad3a237f9ce69deedcb000d1d2$42a238872e50328ddf1740643d18c6a15c8c4e6f7229474f3241e3c53ab490b06bf565ce01de41298885955397d2ba1c7cc84b66c90e4253c2316ef7a420e046',1,1,1,1,1,'2026-10-30 20:05:40','2026-10-30 20:05:40','developer',NULL,1,1,1,NULL);
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60001,'branch_manager_faisal','مدير الفرع — فرع فيصل','scrypt$295fb0f474eeb1cb2a7f155c23305eac$37068379a00ec41b3e0697024e1212a602319284494db77e32920b48f71fc50401c3dd132f80beeed24a363f18a02109e26c6639bb92963bfaaf5cd111e78a80',0,0,1,1,1,'2026-10-30 20:13:52','2026-10-30 20:13:52','branch_manager',1,1,1,0,'flexible');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60002,'kitchen_manager_faisal','مدير المطبخ — فرع فيصل','scrypt$347404153a7feebd7b0565821dfff8a2$5c77b9ec4548473b9c85b283b96c41f8911895c9b4020299cbaae2a0c1052e2ead9bbfc30d43706ef1c2eb056bc5451f9e83d457598f946a3dcaff0eeb3633f6',1,1,1,1,1,'2026-10-30 20:13:52','2026-10-30 20:13:52','kitchen_manager',1,0,1,1,'flexible');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60003,'supervisor_faisal','المشرف — فرع فيصل','scrypt$cfee5603bf910b9ff2844e390ff7c66f$ed8d1d0f000efaf3b4492f96e97a8bfd0f4b8965e9d380268db40763a88999058b2472d01c2120a4ccd1ca2910867973306288d1bb68883418b7bb9826dfd192',0,0,1,1,1,'2026-10-30 20:13:52','2026-10-30 20:13:52','shift_manager',1,0,1,0,'flexible');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60004,'station_faisal_morning','موظف السخان الصباحي — فرع فيصل','scrypt$8dab91364e7b64cdd13856d3bd30c243$cafad0cc0d7498b8efc522c7c9e5e9f24c1923e895cf5b283f7a3328046a5de5716873fe5172fac45d1d4b13f68fa6b1f717d60290d65026a4fb5ac8cfd3a709',1,0,0,1,1,'2026-10-30 20:13:52','2026-10-30 20:13:52','station',1,0,0,0,'morning');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60005,'station_faisal_evening','موظف السخان المسائي — فرع فيصل','scrypt$9c05379ac487517d0d8eab6a26bcf5c7$44d409846e461a8bc1c554cf38b09b601fe963b1b490d0ca631a738066fbe1029d49554507f329b9591fc27c94a14ab2cc0f649031d5767343321e804e48a042',1,0,0,1,1,'2026-10-30 20:13:52','2026-10-30 20:13:52','station',1,0,0,0,'evening');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60006,'kitchen_faisal_morning','موظف المطبخ الصباحي — فرع فيصل','scrypt$7e7fa8790e17aa0602cda750eb70de35$f86af2a24385cc0f4fec7a37d3eb2dab97598eda928a463225f5c9e24169f2b3c3b19bf53ff049af8725b38381762f1e342725d21ac7cdea0a7245c3bbf41ba2',0,1,0,1,1,'2026-10-30 20:13:53','2026-10-30 20:13:53','kitchen',1,0,0,0,'morning');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60007,'kitchen_faisal_evening','موظف المطبخ المسائي — فرع فيصل','scrypt$032057f188c3c55977db011eace1f977$39d578b96f56bf65375d1de9ce1ebf74f42667bb7ff49a1ae92311dd1b068cb82b8ed7e26c92cf90f2a06c64da7c81bd078d4075303b218b8659812ab698db9f',0,1,0,1,1,'2026-10-30 20:13:53','2026-10-30 20:13:53','kitchen',1,0,0,0,'evening');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60008,'branch_manager_sufian','مدير الفرع — فرع سفيان','scrypt$0b6a96f4ef623e74060519e613350520$40e0a70bea17fc604a50cc006c529752fe873a3b070a3bfce732312d20fc7df0d6770ce7228dca55a0f3f3047b4a4b0cc7d1c604589ff2992960c565520eae9e',0,0,1,1,1,'2026-10-30 20:13:53','2026-10-30 20:13:53','branch_manager',2,1,1,0,'flexible');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60009,'kitchen_manager_sufian','مدير المطبخ — فرع سفيان','scrypt$18ffb10aedfa7a0507f117f9e4bb6583$f3f326a72e134b6814bd2cf48cb33113778c2058345ce3a8a07477d2234cef4898f8589a45ffb884ad59d2b65cb58d9dc98142f0e272ca714b0b080cbaeb56a2',1,1,1,1,1,'2026-10-30 20:13:53','2026-10-30 20:13:53','kitchen_manager',2,0,1,1,'flexible');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60010,'supervisor_sufian','المشرف — فرع سفيان','scrypt$d15436f7704be558c34300f54a1b0bf7$c9b53ba1650d404985fee229c769463d259bb2bfe21edc692a13d445f9d9bdbf90261e93baf1dee9b614e93f43048fc2bfdd95fb924cdc8ce68dc0b0c6bf6156',0,0,1,1,1,'2026-10-30 20:13:53','2026-10-30 20:13:53','shift_manager',2,0,1,0,'flexible');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60011,'station_sufian_morning','موظف السخان الصباحي — فرع سفيان','scrypt$7113020a83e48d559037ec6892944e1c$5a18fbc5f022763363978522c577524955151d701a3306947ae075faf4c1518e9418b493d7e1d20566eabeea7038d66c613ec589d51384d18a2091abf403142b',1,0,0,1,1,'2026-10-30 20:13:54','2026-10-30 20:13:54','station',2,0,0,0,'morning');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60012,'station_sufian_evening','موظف السخان المسائي — فرع سفيان','scrypt$8c58116ed87fc5c1714556fa6b9551e7$73e2accd1e3a8f52ccf470f93b7e2030faae91ecaf06571bd4a7c53f29e808bbb464c425322e542f8823500868f7eb4b9b33918765a47c765e56878e07e9e20a',1,0,0,1,1,'2026-10-30 20:13:54','2026-10-30 20:13:54','station',2,0,0,0,'evening');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60013,'kitchen_sufian_morning','موظف المطبخ الصباحي — فرع سفيان','scrypt$2cae0f6147d397a220c327ec809bdc88$25a87c1ccb7f878491264233b1c733219d259a7ca9c35d87fd4a2ca4804b5070edf881a26a875a981256791f4d3e082f8d206932fe2c7ebbd3031e90aeb0c3d4',0,1,0,1,1,'2026-10-30 20:13:54','2026-10-30 20:13:54','kitchen',2,0,0,0,'morning');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60014,'kitchen_sufian_evening','موظف المطبخ المسائي — فرع سفيان','scrypt$c44c4f1706e91f282dbba439f8275bd3$4e47303e0b31066afec9ecc9bc2e073170f12555acf8aeba3647833d296ccff85732b8ee925faa98f6af573a65ea9f1bfb42efaa6fdac85f0f08518b71612e25',0,1,0,1,1,'2026-10-30 20:13:54','2026-10-30 20:13:54','kitchen',2,0,0,0,'evening');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60015,'branch_manager_rafidia','مدير الفرع — فرع رفيديا','scrypt$cffbeea8b6c83b5ad96b61e3fa11ab55$22b1490d7c1c5d271798aecd35eb46712e294dc3ec976cd618afca270d7164f1b27e83ed23338a491babeb28388b73cb60f0e7862da502e39c8141bcb10b2f4d',0,0,1,1,1,'2026-10-30 20:13:54','2026-10-30 20:13:54','branch_manager',3,1,1,0,'flexible');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60016,'kitchen_manager_rafidia','مدير المطبخ — فرع رفيديا','scrypt$303f64731afcee0da8884b0b34d529ba$149e7e20e21131be482533fe758a2cb6b044dbc37861774752fd12dfb32bbdcc2057beb407942692db08fa1c02e1aa95287e0e5eaef87a986103d3873f0b87a9',1,1,1,1,1,'2026-10-30 20:13:54','2026-10-30 20:13:54','kitchen_manager',3,0,1,1,'flexible');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60017,'supervisor_rafidia','المشرف — فرع رفيديا','scrypt$56111952f4b91e90d0e7594696410d8c$3783511b7f9e2770ca596dbb7457b206c02f97b30456f14610cee10ce07519d3963b9be0108026fd2b530bac3b46019f232043a1fc36958436585ac1d1d94e14',0,0,1,1,1,'2026-10-30 20:13:55','2026-10-30 20:13:55','shift_manager',3,0,1,0,'flexible');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60018,'station_rafidia_morning','موظف السخان الصباحي — فرع رفيديا','scrypt$e17c845bbe1fc26e1afe5ebafbbe5be5$de0d9c5232c149e053839a99862be47b33c38c217453b0b8048bde01ee4d6d361f38daebf0f614c0a70f417d0f4abb396829cd2cd84a4060063d81b42b10c754',1,0,0,1,1,'2026-10-30 20:13:55','2026-10-30 20:13:55','station',3,0,0,0,'morning');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60019,'station_rafidia_evening','موظف السخان المسائي — فرع رفيديا','scrypt$a11adc5e1873f2619cdc46c16ba13d67$70b0137b23017693ccb1bc86a0943f86c777ae8a8f1d290929d021ce61a2fb6976f2826229b06e951e38685ea19a81881ea64d4770b6ce102cace70498bd2b77',1,0,0,1,1,'2026-10-30 20:13:55','2026-10-30 20:13:55','station',3,0,0,0,'evening');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60020,'kitchen_rafidia_morning','موظف المطبخ الصباحي — فرع رفيديا','scrypt$771d8d985af5dddd2d4ea4cd3d34be5e$18ed00043777136d513e4d6e2875e8c2dcd6745e2237581ef4d2cb14cc0d4eb40fc647f965744ecd3bde8299631e082a33645fad307c644e213f3fa52a60681c',0,1,0,1,1,'2026-10-30 20:13:55','2026-10-30 20:13:55','kitchen',3,0,0,0,'morning');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60021,'kitchen_rafidia_evening','موظف المطبخ المسائي — فرع رفيديا','scrypt$c45dc1befadc2a31565773f04fd8ecfc$b2cf883c2839a964086c6615fc1f63040c975ae076ddbdd385f540dfe2bdfd304f9757ee48ec35ab3962cbad740072a2ca4a5b69b8a10f7469d7ffea84fe08ea',0,1,0,1,1,'2026-10-30 20:13:55','2026-10-30 20:13:55','kitchen',3,0,0,0,'evening');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60022,'branch_manager_plaza_mall','مدير الفرع — فرع بلازا مول','scrypt$8130b308726de728235d6a408e710ee3$b601d9818c2d089a4882d166e719958ef1c67205fd465303e8c9fc75d20d6821dd99083db9e431fbe11a103dc9e076c52d89afe923ee53411fca734c7bd958ff',0,0,1,1,1,'2026-10-30 20:13:56','2026-10-30 20:13:56','branch_manager',4,1,1,0,'flexible');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60023,'kitchen_manager_plaza_mall','مدير المطبخ — فرع بلازا مول','scrypt$b9c9e6e620d6291ff45e80906b0585a2$85a10641285eb6f0694d03fbde18b8e0275c406d67af031a38a4a5dc95064f15c2aba21504b6baafaf8a6f1b74f366edfcae2a195366eed55230e377a298b005',1,1,1,1,1,'2026-10-30 20:13:56','2026-10-30 20:13:56','kitchen_manager',4,0,1,1,'flexible');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60024,'supervisor_plaza_mall','المشرف — فرع بلازا مول','scrypt$1ee3697ab6de6af7c484f124c36060da$6b09e014e36e3968a4c70de81d5f514963a2d38bdbab2f5afdce3d7f61fc81006bb04fd419391008f607f660101f81baad4f47e2ecb251a21aa853cb2c2b0ca3',0,0,1,1,1,'2026-10-30 20:13:56','2026-10-30 20:13:56','shift_manager',4,0,1,0,'flexible');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60025,'station_plaza_mall_morning','موظف السخان الصباحي — فرع بلازا مول','scrypt$681835592ceb4af7cc406d80a63437f5$646e8bb687a11e574aa06cb2378fd27b83c39a93ee7101118c794ab9eac5423f808334b60da180b2188b7b6a85f346c44e6a9c7ebe8379165ec5ca6f653c21e2',1,0,0,1,1,'2026-10-30 20:13:56','2026-10-30 20:13:56','station',4,0,0,0,'morning');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60026,'station_plaza_mall_evening','موظف السخان المسائي — فرع بلازا مول','scrypt$bd459c662063effa1cc028e536be02af$bda6f6c5030d15019838ed5d841aa47315c3cfb0382af0df6ebed1696f8a7cf80aecaf4b1459c5e400608cc312277d953a6aba66033809590159d254306046e8',1,0,0,1,1,'2026-10-30 20:13:56','2026-10-30 20:13:56','station',4,0,0,0,'evening');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60027,'kitchen_plaza_mall_morning','موظف المطبخ الصباحي — فرع بلازا مول','scrypt$7472659d1d7f7247d233c6b410277750$ecf5109647250c1c2e0853c013a2b138da31958b757a9947a2f21e1e61ef829f84c7980ea54cbb5e404b3b18e643a0b1d0d3d4472005909291e8c42cad6f8422',0,1,0,1,1,'2026-10-30 20:13:57','2026-10-30 20:13:57','kitchen',4,0,0,0,'morning');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60028,'kitchen_plaza_mall_evening','موظف المطبخ المسائي — فرع بلازا مول','scrypt$adc2b9c57cccda6b233ef2b0a8467ad4$c81e304318269d25000d7052505bac029dfbbf491f435e1413803e90acd5151f8217456b4a627c15131d1dbe6e98b306c0f638775d43048d23f66323ff92189e',0,1,0,1,1,'2026-10-30 20:13:57','2026-10-30 20:13:57','kitchen',4,0,0,0,'evening');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60029,'branch_manager_tira','مدير الفرع — فرع الطيرة','scrypt$e08358c0276af4e8ff0134f10c57245b$420f45f4b61d7fa20d9aa22ba977fd318db853bb18c05f432e939789b24033472e8ffed8a277524c41ddfe1dd7163e80b8f1e88df3a13ae49cc5df98adead891',0,0,1,1,1,'2026-10-30 20:13:57','2026-10-30 20:13:57','branch_manager',5,1,1,0,'flexible');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60030,'kitchen_manager_tira','مدير المطبخ — فرع الطيرة','scrypt$833dc914822656c2e946fc63b5265ee0$1ff47a962b7039cc4cda35a53685c043ea10cd007a4d3d3ed578b54004d17372b4a53fc5b454bf1ff03058db6904f25db17d8303eb247fd72ab602c9f9fefcd5',1,1,1,1,1,'2026-10-30 20:13:57','2026-10-30 20:13:57','kitchen_manager',5,0,1,1,'flexible');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60031,'supervisor_tira','المشرف — فرع الطيرة','scrypt$2d9bf38f712e91d4d7ef66930006d1ec$d16f4d5309d2af2d47db6a401240e1f50b179cb0592c418c259b8060a90e6991d2aeaba11a9f312e87aa4bdba18da556257754594756dff651fcb68d8e1f434e',0,0,1,1,1,'2026-10-30 20:13:57','2026-10-30 20:13:57','shift_manager',5,0,1,0,'flexible');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60032,'station_tira_morning','موظف السخان الصباحي — فرع الطيرة','scrypt$a2a808741d22d9ec5b41cea5544660f4$6f553d11026fd9177271fbd61b0c6896dccbcf9ef2652f9504e02868559fe5a4b1d00f52c4dc145e7e5db1260fe8a8332574219445b0962db9aad271e5a8a2e7',1,0,0,1,1,'2026-10-30 20:13:57','2026-10-30 20:13:57','station',5,0,0,0,'morning');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60033,'station_tira_evening','موظف السخان المسائي — فرع الطيرة','scrypt$f9b2cfa7da883aaa1739d672fc012fdb$a450c67c6afdd86446956ec5ee5dfd8cc0fbbb53894c6178b6b420f0f224c1f9068bbd5c8459a12c245ecc0de774ba2c2dc732b0470614e28bb8346620b0d1e1',1,0,0,1,1,'2026-10-30 20:13:58','2026-10-30 20:13:58','station',5,0,0,0,'evening');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60034,'kitchen_tira_morning','موظف المطبخ الصباحي — فرع الطيرة','scrypt$f21b948812a9fa92648252b6e96bf890$0a30f7dd514a3579efdde2743a71d6cad2ece02c18e448a7f4e652a2a7a13bae654dec70a9f32f9e894f8f9bd58f4697bd34978868ba0d4024d0496b1f7684bf',0,1,0,1,1,'2026-10-30 20:13:58','2026-10-30 20:13:58','kitchen',5,0,0,0,'morning');
INSERT INTO `staff_users` (`id`,`username`,`display_name`,`password_hash`,`can_station`,`can_kitchen`,`can_manager`,`is_active`,`must_change_password`,`created_at`,`updated_at`,`role`,`branch_id`,`can_manage_users`,`can_broadcast`,`can_extend`,`usual_shift`) VALUES (60035,'kitchen_tira_evening','موظف المطبخ المسائي — فرع الطيرة','scrypt$c337029c8f945f6ba15231458d980570$66d07a02d05974a80ce3f2479309b776f9c3b06494eb0b3da262841c1ef01ff265e5c1068707b5a13703361b0a7b28aeccb7eaae23f8c664dc07671730769e65',0,1,0,1,1,'2026-10-30 20:13:58','2026-10-30 20:13:58','kitchen',5,0,0,0,'evening');

-- Table users
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `openId` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(320) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `loginMethod` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('user','admin') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `lastSignedIn` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `users_openId_unique` (`openId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=210001;
INSERT INTO `users` (`id`,`openId`,`name`,`email`,`loginMethod`,`role`,`createdAt`,`updatedAt`,`lastSignedIn`) VALUES (1,'cEfmMJGrY2PHABnDgbjKNJ','mosab qotub','mosabqotub00@gmail.com','google','user','2026-10-30 19:48:17','2026-10-30 20:16:22','2026-10-30 20:16:22');

SET foreign_key_checks=1;
-- Export complete.
